/**
 * Chart data assembly — real historical NAV from the backend, plus
 * intra-day interpolation anchored on today's estimated NAV.
 *
 * 场外公募基金每个交易日只有 1 个官方净值，没有分时 K 线：
 *   - 1D / 1W / 1M → 真实日净值（来自天天基金 Lsjz 接口）
 *   - 分时（intraday）→ 起点=昨日真实 dwjz，终点=今日 gsz（实时估算），
 *                       中间用平滑插值生成连续曲线，并标注为"估算"
 *
 * 走势图的时段按 `market` 切换（决定曲线起止时间），X 轴标签**统一用北京时间**。
 *   - A 股：09:30 - 15:00（北京时间）
 *   - 港股：09:30 - 16:00（北京时间）
 *   - 美股：21:30 - 04:00 次日（北京时间；对应美东 09:30 - 16:00）
 */

import type { FundHistoryPoint } from '../services/api';
import { detectFundMarket, type FundMarket } from './fundMarket';
export type { FundMarket } from './fundMarket';

export type RangeKey = 'intraday' | '1D' | '1W' | '1M';

export interface ChartPoint {
  /** Unix ms timestamp */
  t: number;
  /** Net asset value at this point */
  v: number;
  /** Marker indicating whether this point is a real daily close. */
  real?: boolean;
  /** Optional display time (e.g. for US chart, use NY local time) */
  displayTime?: string;
}

export type DataSource = 'real' | 'estimated' | 'mixed';

export interface ChartSeries {
  points: ChartPoint[];
  source: DataSource;
  note?: string;
  /** Market this series represents (for X-axis label formatting) */
  market?: FundMarket;
  /**
   * True when today's session has not opened yet. During pre-market
   * the series is a flat baseline at `previous` (no interpolation),
   * because today's gsz is not yet distinguishable from yesterday's dwjz.
   * Callers may use this flag to suppress animations, badges, or claims
   * that "today's data is present."
   */
  preMarket?: boolean;
}

/** Tiny deterministic PRNG so fallback walks look stable per fund */
function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashCode(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  }
  return h;
}

/**
 * Mean-reverting random walk around the linear trend. The walk drifts toward
 * the linear interpolation each step (so it stays anchored on the trend) plus
 * a small jitter. This keeps both directions of fluctuation visible:
 *   - UP trend: line goes from prev → current but you still see mid-day dips below prev
 *   - DOWN trend: line goes from prev → current but you still see mid-day rises above prev
 *
 * (Previously the old multiplicative-walk + bias logic produced negative scales
 *  when the random walk happened to go opposite the desired span — flipping the
 *  walk and erasing the "below prev / above prev" data.)
 */
function interpolate(
  startValue: number,
  endValue: number,
  steps: number,
  volatility: number,
  rand: () => number
): number[] {
  const series: number[] = new Array(steps);
  const span = endValue - startValue;
  const jitterScale = startValue * volatility * 8; // 抖幅 ≈ ±0.5% of baseline per step
  const revertRate = 0.18;                         // 多少比例拉向线性趋势（每步）

  series[0] = startValue;
  for (let i = 1; i < steps; i++) {
    const linearHere = startValue + span * (i / (steps - 1));
    const shock = (rand() - 0.5) * 2 * jitterScale;
    const drift = (linearHere - series[i - 1]) * revertRate;
    series[i] = series[i - 1] + drift + shock;
  }

  // 强制端点对齐到精确 startValue / endValue
  series[0] = startValue;
  series[steps - 1] = endValue;
  return series;
}

/** Convert YYYY-MM-DD to Unix ms at local midnight. */
function dateToTs(date: string): number {
  const parts = date.split('-').map(Number);
  return new Date(parts[0], parts[1] - 1, parts[2]).getTime();
}

/** 简化的 US DST：3-10 月 = 夏令时（NY = UTC-4），否则冬令时（UTC-5） */
function isUSDST(d: Date): boolean {
  const m = d.getMonth() + 1;
  return m >= 3 && m <= 10;
}

/** Get the intraday window in Beijing time (startTs, endTs) for the given market. */
function getIntradayWindow(
  market: FundMarket,
  now: number
): { startTs: number; endTs: number; xLabelMode: 'local' | 'ny' } {
  const d = new Date(now);
  const today = (y: number, m: number, day: number, h: number, min: number) =>
    new Date(y, m, day, h, min, 0, 0).getTime();

  if (market === 'us') {
    // US session 跨日：今天 21:30 → 明天 04:00（夏令）/ 05:00（冬令）
    const dst = isUSDST(d);
    const startH = dst ? 21 : 22;
    const startM = 30;
    const closeH = dst ? 4 : 5;
    const DAY = 24 * 3600 * 1000;

    const todayStart = today(d.getFullYear(), d.getMonth(), d.getDate(), startH, startM);
    const todayClose = today(d.getFullYear(), d.getMonth(), d.getDate(), closeH, 0);

    let startTs: number;
    let endTs: number;

    if (now < todayClose) {
      // 凌晨 0–close：US session 从昨天 21:30 持续到今天 close
      startTs = todayStart - DAY;
      endTs = Math.min(now, todayClose);
    } else if (now < todayStart) {
      // 白天 close–21:30：最近一个已结束 session（昨天 21:30 → 今天 close）
      startTs = todayStart - DAY;
      endTs = todayClose;
    } else {
      // 21:30–24:00：今天的 US session 正在进行
      startTs = todayStart;
      endTs = now;
    }

    return { startTs, endTs, xLabelMode: 'ny' };
  }
  if (market === 'hk') {
    const startTs = today(d.getFullYear(), d.getMonth(), d.getDate(), 9, 30);
    const endTs = today(d.getFullYear(), d.getMonth(), d.getDate(), 16, 0);
    return { startTs, endTs, xLabelMode: 'local' };
  }
  // A 股 / other
  const startTs = today(d.getFullYear(), d.getMonth(), d.getDate(), 9, 30);
  const endTs = today(d.getFullYear(), d.getMonth(), d.getDate(), 15, 0);
  return { startTs, endTs, xLabelMode: 'local' };
}

/**
 * Build the chart series for the requested range, given the real history
 * (if available) and the current/previous NAV.
 *
 * @param fundName 基金名 — 用于判断市场（美股/QDII/港股/A股）
 * @param fundCode 基金代码
 */
export function buildSeries(
  code: string,
  current: number,
  previous: number,
  range: RangeKey,
  history: FundHistoryPoint[] = [],
  fundName?: string,
  fundCode?: string,
  kind?: 'fund' | 'stock'
): ChartSeries {
  const market = detectFundMarket(fundName, fundCode);
  const rand = mulberry32(hashCode(code + range));
  const now = Date.now();

  // ─── 1D: last 5 trading days of real NAV + today's live tick ───
  if (range === '1D' && history.length >= 1) {
    const slice = history.slice(-5);
    const points: ChartPoint[] = slice.map(p => ({
      t: dateToTs(p.date),
      v: p.dwjz,
      real: true,
    }));
    if (current > 0 && current !== previous) {
      points.push({ t: now, v: current, real: false });
    }
    return {
      points,
      source: 'real',
      market,
      note: '数据来源：东方财富历史单位净值（每个交易日 1 个收盘点）+ 当日实时估值',
    };
  }

  // ─── 1W / 1M: real daily NAV ─────────────────────────────────
  if ((range === '1W' || range === '1M') && history.length >= 2) {
    const slice = range === '1W' ? history.slice(-7) : history.slice(-30);
    const points: ChartPoint[] = slice.map(p => ({
      t: dateToTs(p.date),
      v: p.dwjz,
      real: true,
    }));
    if (current > 0 && current !== previous) {
      points.push({ t: now, v: current, real: false });
    }
    return {
      points,
      source: 'real',
      market,
      note: '数据来源：东方财富历史单位净值（每个交易日 1 个收盘点）+ 当日实时估值',
    };
  }

  // ─── intraday: 按市场时段的插值曲线（X 轴统一北京时间）────
  if (range === 'intraday') {
    const win = getIntradayWindow(market, now);
    const { startTs: rawStartTs, endTs: rawEndTs } = win;
    let startTs = rawStartTs;
    let endTs = rawEndTs;

    // 边界处理：
    //   - 开盘前（now < startTs）：今日 session 尚未开始。当前 gsz ≈ 昨日
    //     dwjz，不做随机插值（避免被误读为"昨日走势"），而是用整个今日
    //     session 窗口绘制一条平台线，右侧 tick = current。
    //   - 盘中（startTs ≤ now ≤ endTs）：startTs → now + interpolate
    //   - 已收盘（now ≥ endTs）：完整 session + interpolate
    const preMarket = now < startTs;
    if (preMarket) {
      // 完整今日 session 窗口（保留 X 轴标签 09:30–15:00 等）
      endTs = rawEndTs;
    } else if (now < endTs) {
      // 盘中：终点 = now
      endTs = now;
    }
    // else: 已收盘 → endTs 保持 close

    // 极端防呆：startTs == endTs 时给 1 分钟宽度
    if (endTs <= startTs) {
      endTs = startTs + 60_000;
    }

    let points: ChartPoint[];
    if (preMarket) {
      // 平台线 — 两点首尾由 SVG 连成直线
      points = [
        { t: startTs, v: previous, real: true },
        { t: endTs,   v: current,  real: false },
      ];
    } else {
      const steps = 240;
      const series = interpolate(previous, current, steps, 0.0006, rand);
      // X 轴统一用北京时间（北京时间本地时间）
      points = series.map((v, i) => ({
        t: startTs + (i / (steps - 1)) * (endTs - startTs),
        v,
      }));
      if (points.length > 0) {
        points[0] = { t: startTs, v: previous, real: true };
        points[points.length - 1] = { t: endTs, v: current, real: true };
      }
    }

    const isStock = kind === 'stock' || /^[A-Za-z]{1,5}$/.test(code.trim()) || /^\d{4,5}$/.test(code.trim()) || (/^\d{6}$/.test(code.trim()) && /^(60|68|00|30|8)/.test(code.trim()));
    const stockNote = market === 'us'
      ? `分时曲线为基于昨日收盘与今日实时行情的插值（仅供趋势参考）。时段：${formatHHMM(startTs)} - ${formatHHMM(endTs)}（北京时间，对应美股 09:30 - 16:00 美东时间）。`
      : '分时曲线为基于昨日收盘与今日实时行情的插值（仅供趋势参考）';
    const fundNote = market === 'us'
      ? `场外基金无分时 K 线，曲线为基于昨日收盘与今日实时估值的插值（仅供趋势参考）。时段：${formatHHMM(startTs)} - ${formatHHMM(endTs)}（北京时间，对应美股 09:30 - 16:00 美东时间）。`
      : '场外基金无分时 K 线，曲线为基于昨日收盘与今日实时估值的插值（仅供趋势参考）';

    return {
      points,
      source: 'estimated',
      market,
      preMarket,
      note: preMarket
        ? `今日尚未开盘 — 平台线为昨日收盘 ¥${previous.toFixed(4)} 基准，右侧 tick 为当前估值；等待 ${formatHHMM(rawEndTs)} 开盘`
        : (isStock ? stockNote : fundNote),
    };
  }

  // Fallback
  const points: ChartPoint[] = [
    { t: now - 24 * 60 * 60 * 1000, v: previous, real: true },
    { t: now, v: current, real: true },
  ];
  return { points, source: 'estimated', market, note: '数据不足，仅展示两点' };
}

/** X 轴刻度标签：统一用北京时间 HH:MM */
export function formatTick(t: number, range: RangeKey): string {
  if (range === 'intraday') {
    const d = new Date(t);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }
  return `${new Date(t).getMonth() + 1}/${new Date(t).getDate()}`;
}

/** Tooltip：统一用北京时间 */
export function formatTooltip(t: number, range: RangeKey): string {
  const d = new Date(t);
  if (range === 'intraday') {
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** 把 Unix ms 转成 "HH:MM"（北京时间） */
function formatHHMM(t: number): string {
  const d = new Date(t);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function changePct(current: number, previous: number) {
  if (previous <= 0) return 0;
  return ((current - previous) / previous) * 100;
}
